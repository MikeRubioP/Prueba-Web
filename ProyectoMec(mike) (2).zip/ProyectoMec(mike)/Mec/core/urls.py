from django.urls import path
from .views import *

urlpatterns = [
    path('', home, name='home'),
    path('AgregarCliente', AgregarCliente, name='AgregarCliente'),
    # --------------Login-RegistroUser----------------
    path('login/', login, name='login'),
    path('logout/', cierre_sesion, name='cierre_sesion'),
    # -----------------------------------------------------
    path('ListarCliente',ListarCliente,name="ListarCliente"),
    path('AgregarServicio', AgregarServicio, name='AgregarServicio'),
    path('ModificarCliente/<id>',ModificarCliente,name="ModificarCliente"),
    path('EliminarCliente/<id>',EliminarCliente,name="EliminarCliente"),
    path('ListarServicio',ListarServicio,name="ListarServicio"),
    path('ModificarServicio/<id>',ModificarServicio,name="ModificarServicio"),
    path('EliminarServicio/<id>',EliminarServicio,name="EliminarServicio"),
    path('Mec_Alan', Mec_Alan, name='Mec_Alan'),
    path('Mec_Victor', Mec_Victor, name='Mec_Victor'),
    path('Mec_Pavel', Mec_Pavel, name='Mec_Pavel'),
    path('Trabajo_1', Trabajo_1, name='Trabajo_1'),
    path('Trabajo_2', Trabajo_2, name='Trabajo_2'),
    path('Trabajo_3', Trabajo_3, name='Trabajo_3'),
    path('Trabajo_4', Trabajo_4, name='Trabajo_4'),
    path('Trabajo_5', Trabajo_5, name='Trabajo_5'),
    path('Trabajo_6', Trabajo_6, name='Trabajo_6'),
]
