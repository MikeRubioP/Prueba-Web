from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout     # para autenticacion
from django.contrib.auth.decorators import login_required   # para proteccion de rutas
from django.contrib.auth.models import User  
from .models import *
from .forms import *

# Create your views here.

def home(request):
    request.session["usuario"]="usuario"
    usuario=request.session["usuario"]
    context={'usuario':usuario}
    return render(request, 'core/home.html',context)

def AgregarCliente(request):
    form = ClienteForm()
    datos = {
        'form': form
    }
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            datos['mensaje'] = 'cliente agregado'

    return render(request, "core/agregarCliente.html", datos)

def login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        request.session['username']=username
        return redirect('home')
    return render(request, 'core/login.html')

def cierre_sesion(request):

    # Función para eliminar o cerrar la sesión del usuario.
    logout(request)
    return redirect('/')  # redirige al home.


def ListarCliente(request):
    cliente = Cliente.objects.all()

    datos = {
        "clientes": cliente
    }

    return render(request, "core/ListarCliente.html", datos)

def ModificarCliente(request, id):
    cliente = Cliente.objects.get(rut=id)
    datos = {
        'form': ClienteForm(instance=cliente)
    }
    if request.method == 'POST':
        formulario = ClienteForm(data=request.POST, instance=cliente)
        if formulario.is_valid:
            formulario.save()
            datos['mensaje'] = "Cliente modificado correctamente"
    return render(request, "core/ModificarCliente.html", datos)

def EliminarCliente(request, id):
    cliente = Cliente.objects.get(rut=id)
    cliente.delete()
    return redirect(to="ListarCliente")



def ListarServicio(request):
    servicio = Servicios.objects.all()

    datos = {
        "servicios": servicio
    }

    return render(request, "core/ListarServicio.html", datos)

def ModificarServicio(request, id):
    servicio = Servicios.objects.get(rut=id)
    datos = {
        'form': ClienteForm(instance=servicio)
    }
    if request.method == 'POST':
        formulario = ServicioForm(data=request.POST, instance=servicio)
        if formulario.is_valid:
            formulario.save()
            datos['mensaje'] = "Servicio modificado correctamente"
    return render(request, "core/ModificarServicio.html", datos)


def EliminarServicio(request, id):
    servicio = Servicios.objects.get(rut=id)
    Servicios.delete()
    return redirect(to="ListarServicio")

def AgregarServicio(request):
    form = ServicioForm()
    datos = {
        'form': form
    }
    if request.method == 'POST':
        form = ServicioForm(request.POST)
        if form.is_valid():
            form.save()
            datos['mensaje'] = 'servicio agregado'

    return render(request, "core/AgregarServicio.html", datos)

def Mec_Alan(request):
    return render(request, 'core/Mecanicos/Mec_Alan.html')

def Mec_Victor(request):
    return render(request, 'core/Mecanicos/Mec_Victor.html')

def Mec_Pavel(request):
    return render(request, 'core/Mecanicos/Mec_Pavel.html')

def Trabajo_1(request):
    return render(request, 'core/Trabajos/Trabajo_1.html')

def Trabajo_2(request):
    return render(request, 'core/Trabajos/Trabajo_2.html')

def Trabajo_3(request):
    return render(request, 'core/Trabajos/Trabajo_3.html')

def Trabajo_4(request):
    return render(request, 'core/Trabajos/Trabajo_4.html')

def Trabajo_5(request):
    return render(request, 'core/Trabajos/Trabajo_5.html')

def Trabajo_6(request):
    return render(request, 'core/Trabajos/Trabajo_6.html')

