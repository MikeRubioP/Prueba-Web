from django import forms
from django.forms import ModelForm
from .models import *

class ClienteForm(ModelForm):
    class Meta:
        model = Cliente
        fields = ['rut','nombre', 'apellido', 'direccion', 'comuna', 'telefono', 'correo']


class ServicioForm(ModelForm):
    class Meta:
        model = Servicios
        fields = ['id', 'nombre','descripcion', 'precio']