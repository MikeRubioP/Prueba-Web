from django.db import models

    


class Cliente(models.Model):
    rut = models.CharField(max_length=9, primary_key=True, verbose_name="rut")
    nombre = models.CharField(max_length=30,verbose_name="nombre")
    apellido = models.CharField(max_length=40 , verbose_name='apellido')
    direccion = models.CharField(max_length=80,verbose_name="direccion")
    comuna = models.CharField(max_length=80,verbose_name="comuna")
    telefono = models.IntegerField(verbose_name="telefono")
    correo = models.CharField(max_length=50,verbose_name='correo')

    def __str__(self):
        return self.nombre

class Servicios(models.Model):
    id = models.IntegerField(primary_key=True, verbose_name="id")
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()
    precio = models.DecimalField(max_digits=8, decimal_places=2)

    def str(self):
        return self.nombre